import { useState, useEffect } from "react"
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom"
import Sidebar from "./components/SideBar"
import Home from "./pages/Home"
import Usuarios from "./pages/Gestionater"
import Excel from "./pages/Excel"
import Curriculum from "./pages/Curriculum"
import Login from "./pages/Login"
import "./App.css"

import { useAuth, AuthProvider } from "./context/AuthContext"


function AppContent() {
  const { isAuthenticated, loading } = useAuth()

  if (loading) {
    return <div className="loading">Cargando...</div>
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      {isAuthenticated ? (
        <>
          <Route
            path="/*"
            element={
              <div className="app-container">
                <Sidebar />
                <main className="main-content">
                  <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/usuarios" element={<Usuarios />} />
                    <Route path="/excel" element={<Excel />} />
                    <Route path="/curriculum" element={<Curriculum />} />
                  </Routes>
                </main>
              </div>
            }
          />
        </>
      ) : (
        <Route path="*" element={<Navigate to="/login" replace />} />
      )}
    </Routes>
  )
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  )
}

export default App
