import { GoogleGenerativeAI } from "@google/generative-ai"

const API_KEY = "AIzaSyA_NILKr0ppk9pGg3vCHjA_G9D7mfozbqc"

const genAI = new GoogleGenerativeAI(API_KEY)

export const model = genAI.getGenerativeModel({
  model: "models/gemini-1.5-flash"
})
