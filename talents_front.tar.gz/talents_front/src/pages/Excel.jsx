"use client"

import { useState } from "react"
import "../assets/styles/PageTemplate.css"

function Excel() {
  const [file, setFile] = useState(null)

  const handleFileUpload = (e) => {
    const selectedFile = e.target.files[0]
    if (selectedFile) {
      setFile(selectedFile)
      console.log("Archivo seleccionado:", selectedFile.name)
    }
  }

const enviarArchivo = async () => {
    if (!file) {
      alert("Debes seleccionar un archivo primero")
      return
    }

    // 🚨 PASO 1: Obtener el token JWT
    const token = localStorage.getItem('token'); 
    
    if (!token) {
        alert("Sesión no iniciada. Por favor, inicie sesión primero.");
        return;
    }

    const formData = new FormData()
    formData.append("file", file)

    try {
      const response = await fetch("http://localhost:5163/api/EmployeeImport/upload", {
        method: "POST",
        body: formData,
        // 🚨 PASO 2: Añadir los encabezados (headers) con el token
        headers: {
          'Authorization': `Bearer ${token}` // Formato estándar para JWT
          // Nota: No se debe usar 'Content-Type': 'multipart/form-data' aquí,
          // el objeto FormData lo configura automáticamente y lo hace funcionar.
        }
      })

      if (!response.ok) {
        // Manejar el 401 Unauthorized aquí
        if (response.status === 401) {
            alert("Acceso denegado. Su sesión ha expirado o no tiene permisos.");
        } else {
            const errorText = await response.text()
            alert("Error al procesar: " + errorText)
        }
        return
      }

      alert("Archivo procesado correctamente 😊")

    } catch (err) {
      console.error(err)
      alert("Hubo un error al enviar el archivo")
    }
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Subir Excel</h1>
        <p>Importa datos de empleados desde un archivo Excel</p>
      </div>

      <div className="page-content">
        <div className="content-card">
          <h2>Importar Archivo Excel</h2>

          <div className="upload-area">
            <div className="upload-icon">📁</div>
            <h3>Arrastra tu archivo aquí</h3>
            <p>o haz clic para seleccionar</p>

            <input
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={handleFileUpload}
              className="file-input"
            />
          </div>

          <div className="upload-info">
            <h4>Formato aceptado:</h4>
            <ul>
              <li>Excel (.xlsx, .xls)</li>
              <li>CSV (.csv)</li>
              <li>Máximo 10 MB</li>
            </ul>
          </div>

          <button onClick={enviarArchivo} className="upload-btn">
            Procesar Archivo
          </button>
        </div>
      </div>
    </div>
  )
}

export default Excel
