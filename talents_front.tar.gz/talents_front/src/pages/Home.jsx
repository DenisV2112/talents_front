"use client"

import { useState, useEffect } from "react"
import { model } from "../config/gemini"
import "../assets/styles/Home.css"

function Home() {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  // 📊 Estados del Dashboard
  const [totalEmployees, setTotalEmployees] = useState(0)
  const [activeEmployees, setActiveEmployees] = useState(0)
  const [vacationEmployees, setVacationEmployees] = useState(0)

const loadDashboard = async () => {
  try {
    const res = await fetch("http://localhost:5163/api/Employees");
    const allData = await res.json();

    // Total empleados
    setTotalEmployees(allData.length);

    // Empleados activos (status === "Activo")
    const active = allData.filter(emp =>
      emp.status?.toLowerCase().includes("activo")
    );
    setActiveEmployees(active.length);

    // Empleados en vacaciones (status === "Vacaciones")
    const vacation = allData.filter(emp =>
      emp.status?.toLowerCase().includes("vaca")
    );
    setVacationEmployees(vacation.length);

  } catch (err) {
    console.log("Error cargando estadísticas", err);
  }
};


  useEffect(() => {
    loadDashboard()
  }, [])

  // 🔥 Función que manda la consulta del usuario a la IA
  const askAI = async (text) => {
    const prompt = `
      Eres un asistente que interpreta la consulta del usuario y decides qué tipo de búsqueda ejecutar.

      SOLO RESPONDE EN JSON con:

      {
        "type": "id | name | lastname | document | email | position | salary | professionalProfile | department",
        "value": "dato de la búsqueda"
      }

      Consulta del usuario:
      "${text}"
    `

    const result = await model.generateContent(prompt)
    const response = await result.response.text()

    try {
      return JSON.parse(response.replace(/```json|```/g, "").trim())
    } catch {
      return null
    }
  }

  // 🔍 Buscar usando IA + API
 const buscar = async () => {
    if (!query) return
    setLoading(true)
    setError(null)
    setResults([])
    
    // 🚨 PASO DE AUTENTICACIÓN: Necesitas el token JWT para acceder a la API
    const token = localStorage.getItem('token');
    if (!token) {
        setError("Error: Sesión no iniciada (Token JWT requerido).");
        setLoading(false);
        return;
    }

    try {
      // 1. Preguntar a la IA
      const aiData = await askAI(query)

      if (!aiData?.type || !aiData?.value) {
        throw new Error("La IA no pudo interpretar la búsqueda. Intenta con un formato más claro (ej: 'dame el empleado 10').")
      }

      // 2. Construir el endpoint de Búsqueda Flexible
      const endpoint = `Search/${aiData.type}/${aiData.value}`
      
      // 🚨 CAMBIO CLAVE: Usar la nueva ruta 'Search'
      const res = await fetch(`http://localhost:5163/api/Employees/${endpoint}`, {
          headers: {
              'Authorization': `Bearer ${token}` // Añadir el token de autenticación
          }
      })

      if (res.status === 404) {
          setError(`No se encontraron resultados para ${aiData.type}: ${aiData.value}`);
          return;
      }
      
      if (!res.ok) {
          throw new Error("Error en el servidor al buscar. Verifique la consola.");
      }

      const data = await res.json()
      // La API debe devolver siempre un array, aunque sea de un solo elemento.
      setResults(Array.isArray(data) ? data : [data]) 

    } catch (err) {
      console.error(err);
      setError(err.message || "Error desconocido al buscar información.");
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="home-container">

      {/* 🧩 DASHBOARD SUPERIOR */}
      <div className="stats-container">
        <div className="stat-card">
          <h3>Total Empleados</h3>
          <p>{totalEmployees}</p>
        </div>

        <div className="stat-card active">
          <h3>Activos</h3>
          <p>{activeEmployees}</p>
        </div>

        <div className="stat-card vacations">
          <h3>En Vacaciones</h3>
          <p>{vacationEmployees}</p>
        </div>
      </div>

      <div className="page-header">
        <h1>Inicio</h1>
        <p>Asistente IA para consulta de empleados</p>
      </div>

      {/* 🔍 Buscador Inteligente IA */}
      <div className="search-box">
        <input
          type="text"
          className="search-input"
          placeholder="Pregúntale a la IA: 'Muéstrame el empleado 1', 'Quién trabaja en IT', etc..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <button className="search-btn" onClick={buscar}>
          Consultar IA
        </button>
      </div>

      {loading && <p>Cargando...</p>}
      {error && <p className="error-message">{error}</p>}

      {/* 📌 Resultados */}
      {results.length > 0 && (
        <div className="results-card">
          <h2>Resultados IA</h2>

          <table className="results-table">
            <thead>
              <tr>
                <th>Documento</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Email</th>
                <th>Cargo</th>
                <th>Departamento</th>
              </tr>
            </thead>
            <tbody>
              {results.map((emp) => (
                <tr key={emp.id}>
                  <td>{emp.document}</td>
                  <td>{emp.firstName}</td>
                  <td>{emp.lastName}</td>
                  <td>{emp.email}</td>
                  <td>{emp.position}</td>
                  <td>{emp.department}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

    </div>
  )
}

export default Home
