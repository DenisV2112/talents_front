import { useState, useEffect } from "react";
import jsPDF from "jspdf";
import "../assets/styles/PageTemplate.css";

// ---------------------------
// FUNCIONES AUXILIARES PARA FORMATO
// ---------------------------

// Función para formatear fechas (ej: 2000-07-25T00:00:00 -> 25/07/2000)
const formatDate = (dateString) => {
  if (!dateString) return "N/A";
  try {
    const date = new Date(dateString);
    // Usar toLocaleDateString asegura el formato local (ej: día/mes/año)
    return date.toLocaleDateString("es-ES", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
  } catch {
    return dateString;
  }
};

// Función para formatear el salario como moneda (ej: 6675009 -> $ 6.675.009,00)
const formatCurrency = (number) => {
  if (typeof number !== "number") return "N/A";
  // Usar toLocaleString para formato de moneda local (ej: COP o Símbolo local)
  return number.toLocaleString("es-CO", {
    style: "currency",
    currency: "COP", // Cambia esto según la moneda de tu país (ej: USD, EUR)
    minimumFractionDigits: 2,
  });
};


function Curriculum() {
  const [employees, setEmployees] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // --- Lógica de carga de empleados (ID, Nombre, Apellido) ---
  useEffect(() => {
    const fetchEmployees = async () => {
      setLoading(true);
      setError(null);
      const token = localStorage.getItem("token");

      try {
        // Asumo que /api/Employees devuelve una lista con los campos básicos para el selector
        const response = await fetch("http://localhost:5163/api/Employees", {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!response.ok) {
          throw new Error("Error al cargar empleados: " + response.statusText);
        }

        const data = await response.json();
        setEmployees(data);
      } catch (err) {
        setError("Error al cargar lista de empleados.");
      } finally {
        setLoading(false);
      }
    };

    fetchEmployees();
  }, []);

  // --- Función principal para generar el PDF ---
  const handleGenerateCV = async (e) => {
    e.preventDefault();

    if (!selectedEmployeeId) {
      alert("Por favor, selecciona un empleado.");
      return;
    }

    setLoading(true);
    setError(null);
    const token = localStorage.getItem("token");

    try {
      // 1. OBTENER DATOS DEL EMPLEADO (JSON)
      const dataUrl = `http://localhost:5163/api/Employees/${selectedEmployeeId}`;

      const response = await fetch(dataUrl, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("Error al obtener datos del empleado: " + response.statusText);
      }

      const employee = await response.json();

      // 2. GENERAR EL PDF USANDO jsPDF
      const doc = new jsPDF();
      let yOffset = 15; // Posición inicial vertical
      const xStart = 15;

      // Estilo de sección
      const addSection = (title) => {
        yOffset += 8;
        doc.setFont("helvetica", "bold");
        doc.setFontSize(16);
        doc.text(title, xStart, yOffset);
        yOffset += 2;
        doc.line(xStart, yOffset, 195, yOffset); // Línea divisoria
        yOffset += 8;
      };
      
      const addText = (label, value) => {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(10);
        doc.text(`${label}:`, xStart, yOffset);
        
        doc.setFont("helvetica", "normal");
        doc.text(value, xStart + 40, yOffset); // Ajusta 40 para alinear el valor
        yOffset += 7;
      };


      // --- CABECERA (Nombre y Puesto) ---
      doc.setFont("helvetica", "bold");
      doc.setFontSize(26);
      doc.text(`${employee.firstName} ${employee.lastName}`, xStart, yOffset);
      yOffset += 8;

      doc.setFontSize(16);
      doc.setFont("helvetica", "normal");
      doc.text(employee.position, xStart, yOffset);
      yOffset += 15;


      // --- SECCIÓN CONTACTO ---
      addSection("Contacto");
      addText("Documento", employee.document);
      addText("Email", employee.email);
      addText("Teléfono", employee.phone);
      addText("Dirección", employee.address);
      yOffset += 5;


      // --- SECCIÓN INFORMACIÓN PERSONAL ---
      addSection("Información Personal");
      addText("Fecha Nacimiento", formatDate(employee.dateOfBirth));
      addText("Nivel Educativo", employee.educationLevel);
      addText("Departamento", employee.department);
      addText("Estado Actual", employee.status);
      addText("Fecha Contratación", formatDate(employee.hireDate));
      addText("Salario", formatCurrency(employee.salary));
      yOffset += 5;


      // --- SECCIÓN PERFIL PROFESIONAL ---
      addSection("Perfil Profesional");
      
      doc.setFontSize(12);
      doc.setFont("helvetica", "normal");
      
      const description = employee.professionalProfile || "No se ha proporcionado un perfil profesional detallado.";
      const splitText = doc.splitTextToSize(description, 180); // Ancho máximo
      doc.text(splitText, xStart, yOffset);
      yOffset += (splitText.length * 6) + 10; // Ajustar offset basado en el número de líneas

      // 3. DESCARGAR EL PDF
      const fileName = `CV_${employee.lastName}_${employee.firstName}_${employee.id}.pdf`;
      doc.save(fileName); 

      alert(`Curriculum de ${employee.firstName} ${employee.lastName} generado y descargado.`);

    } catch (err) {
      setError(err.message);
      console.error(err);
      alert("Error en la generación del CV: " + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      {/* ... (Tu JSX de la cabecera) ... */}
      <div className="page-header">
        <h1>Generador de Curriculum</h1>
        <p>Selecciona un empleado para generar su CV en formato PDF.</p>
      </div>

      <div className="page-content">
        <div className="content-card">
          <h2>Selección de Empleado</h2>
          
          {loading && <p>Cargando lista de empleados...</p>}
          {error && <p style={{ color: 'red' }}>Error: {error}</p>}

          <form className="form-container" onSubmit={handleGenerateCV}>
            {/* Campo de selección de empleado */}
            <div className="form-group">
              <label htmlFor="employeeSelect">Seleccionar Empleado</label>
              <select
                id="employeeSelect"
                value={selectedEmployeeId}
                onChange={(e) => setSelectedEmployeeId(e.target.value)}
                required
                disabled={loading || employees.length === 0}
              >
                <option value="">-- Selecciona un Empleado --</option>
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.firstName} {emp.lastName} ({emp.position})
                  </option>
                ))}
              </select>
            </div>
            
            <button type="submit" className="submit-btn" disabled={!selectedEmployeeId || loading}>
              {loading ? "Obteniendo Datos..." : "Generar y Descargar CV (Frontend)"}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Curriculum;