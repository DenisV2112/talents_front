import { useEffect, useState } from "react"
import "../assets/styles/PageTemplate.css"

function Usuarios() {
  const [usuarios, setUsuarios] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [isEditing, setIsEditing] = useState(false)

  // FORM DATA SIN ID (id solo existe en modo edición)
  const [formData, setFormData] = useState({
    document: "",
    firstName: "",
    lastName: "",
    dateOfBirth: "",
    address: "",
    phone: "",
    email: "",
    position: "",
    salary: 0,
    hireDate: "",
    status: "",
    educationLevel: "",
    professionalProfile: "",
    department: ""
  })

  const [editId, setEditId] = useState(null)

  const token = localStorage.getItem("token")

  const fetchUsuarios = async () => {
    try {
      const response = await fetch("http://localhost:5163/api/Employees")
      const data = await response.json()
      setUsuarios(data)
    } catch (error) {
      console.error("Error:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchUsuarios()
  }, [])

  const openCreateModal = () => {
    setIsEditing(false)
    setEditId(null) // ← YA NO HAY ID EN CREACIÓN

    setFormData({
      document: "",
      firstName: "",
      lastName: "",
      dateOfBirth: "",
      address: "",
      phone: "",
      email: "",
      position: "",
      salary: 0,
      hireDate: "",
      status: "",
      educationLevel: "",
      professionalProfile: "",
      department: ""
    })

    setShowModal(true)
  }

  const openEditModal = (u) => {
    setIsEditing(true)
    setEditId(u.id) // ← AQUÍ SÍ SE USA EL ID, PERO SIN MODIFICARLO

    setFormData({
      document: u.document,
      firstName: u.firstName,
      lastName: u.lastName,
      dateOfBirth: u.dateOfBirth.split("T")[0],
      address: u.address,
      phone: u.phone,
      email: u.email,
      position: u.position,
      salary: u.salary,
      hireDate: u.hireDate.split("T")[0],
      status: u.status,
      educationLevel: u.educationLevel,
      professionalProfile: u.professionalProfile,
      department: u.department
    })

    setShowModal(true)
  }

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const saveEmployee = async () => {
  try {
    const url = isEditing
      ? `http://localhost:5163/api/Employees/${formData.id}`
      : "http://localhost:5163/api/Employees";

    const method = isEditing ? "PUT" : "POST";

    // Convertir correctamente fechas
    const payload = {
      ...formData,
      dateOfBirth: formData.dateOfBirth === "" ? null : formData.dateOfBirth,
      hireDate: formData.hireDate === "" ? null : formData.hireDate
    };

    const response = await fetch(url, {
      method,
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const text = await response.text();
      alert("Error: " + text);
      return;
    }

    alert(isEditing ? "Empleado actualizado" : "Empleado creado");
    setShowModal(false);
    fetchUsuarios();

  } catch (err) {
    console.error(err);
    alert("Error guardando el empleado");
  }
};


  const eliminarUsuario = async (id) => {
    const confirmDelete = window.confirm("¿Estás seguro de eliminar este usuario?")
    if (!confirmDelete) return

    try {
      const response = await fetch(`http://localhost:5163/api/Employees/${id}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        }
      })

      if (response.status === 401) {
        alert("No autorizado. Debes iniciar sesión.")
        return
      }

      if (!response.ok) {
        alert("No se pudo eliminar el usuario.")
        return
      }

      setUsuarios(usuarios.filter((u) => u.id !== id))
      alert("Usuario eliminado correctamente")

    } catch (error) {
      console.error("Error eliminando usuario:", error)
    }
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Gestión de Usuarios</h1>
        <button className="action-link" onClick={openCreateModal}>➕ Crear Usuario</button>
        <p>Administra los usuarios y empleados del sistema</p>
      </div>

      <div className="page-content">
        <div className="content-card">
          <h2>Usuarios Registrados</h2>

          {loading ? (
            <p>Cargando usuarios...</p>
          ) : (
            <table className="users-table">
              <thead>
                <tr>
                  <th>Documento</th>
                  <th>Nombres</th>
                  <th>Apellidos</th>
                  <th>Fecha Nacimiento</th>
                  <th>Dirección</th>
                  <th>Teléfono</th>
                  <th>Email</th>
                  <th>Cargo</th>
                  <th>Salario</th>
                  <th>Fecha Ingreso</th>
                  <th>Estado</th>
                  <th>Nivel Educativo</th>
                  <th>Perfil Profesional</th>
                  <th>Departamento</th>
                  <th>Acciones</th>
                </tr>
              </thead>

              <tbody>
                {usuarios.map((u) => (
                  <tr key={u.id}>
                    <td>{u.document}</td>
                    <td>{u.firstName}</td>
                    <td>{u.lastName}</td>
                    <td>{u.dateOfBirth}</td>
                    <td>{u.address}</td>
                    <td>{u.phone}</td>
                    <td>{u.email}</td>
                    <td>{u.position}</td>
                    <td>{u.salary}</td>
                    <td>{u.hireDate}</td>
                    <td>{u.status}</td>
                    <td>{u.educationLevel}</td>
                    <td>{u.professionalProfile}</td>
                    <td>{u.department}</td>

                    <td>
                      <button className="action-link" onClick={() => openEditModal(u)}>Editar</button>
                      <button className="action-link delete" onClick={() => eliminarUsuario(u.id)}>Eliminar</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>{isEditing ? "Editar Usuario" : "Crear Usuario"}</h2>

            <div className="modal-form">
              {Object.keys(formData).map((key) => (
                <input
                  key={key}
                  type={key.toLowerCase().includes("date") ? "date" : "text"}
                  name={key}
                  placeholder={key}
                  value={formData[key]}
                  onChange={handleChange}
                />
              ))}

              <button onClick={saveEmployee} className="btn-save">
                {isEditing ? "Actualizar" : "Crear"}
              </button>
              <button onClick={() => setShowModal(false)} className="btn-cancel">Cancelar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Usuarios
