
import { Link, useLocation, useNavigate } from "react-router-dom"

import { useAuth } from "../context/AuthContext"
import "../assets/styles/SideBar.css"

function Sidebar() {
  const location = useLocation()
  const navigate = useNavigate()
  const { setIsAuthenticated } = useAuth()

  const isActive = (path) => location.pathname === path

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("username")
    setIsAuthenticated(false)
    navigate("/login")
  }

  const username = localStorage.getItem("username")

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <h1>Dashboard</h1>
      </div>

      <nav className="sidebar-nav">
        <Link to="/" className={`nav-link ${isActive("/") ? "active" : ""}`}>
          <span className="nav-icon">🏠</span>
          <span className="nav-text">Inicio</span>
        </Link>

        <Link to="/usuarios" className={`nav-link ${isActive("/usuarios") ? "active" : ""}`}>
          <span className="nav-icon">👥</span>
          <span className="nav-text">Gestión de Usuarios</span>
        </Link>

        <Link to="/excel" className={`nav-link ${isActive("/excel") ? "active" : ""}`}>
          <span className="nav-icon">📊</span>
          <span className="nav-text">Subir Excel</span>
        </Link>

        <Link to="/curriculum" className={`nav-link ${isActive("/curriculum") ? "active" : ""}`}>
          <span className="nav-icon">📄</span>
          <span className="nav-text">Crear Curriculum</span>
        </Link>
      </nav>

      <div className="sidebar-footer">
        <div className="user-info">
          <span className="user-icon">👤</span>
          <span className="user-name">{username || "Usuario"}</span>
        </div>
        <button onClick={handleLogout} className="logout-button">
          🚪 Cerrar Sesión
        </button>
      </div>
    </aside>
  )
}

export default Sidebar
