using AutoMapper;
using PruebApi.Data.Entities;
using PruebApi.DTOs;

namespace PruebApi.Common.Mapping;
public class MappingProfile : Profile
{
    public MappingProfile()
    {
        // Esto mapea todos los campos con nombres coincidentes.
        // Asegúrate de que tengas una línea similar a esta:
        CreateMap<Employee, EmployeeDto>().ReverseMap();
    }
}