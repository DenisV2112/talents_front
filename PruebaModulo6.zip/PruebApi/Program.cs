using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using System.Text;
using PruebApi.Data.Database;
using PruebApi.Data.Repositories.Interfaces;
using PruebApi.Data.Repositories.Implementations;
using PruebApi.Services.Interfaces;
using PruebApi.Services.Implementations;
using PruebApi.Common.Mapping;
using PruebApi.Auth;
using PruebApi.Data.Entities;
using PruebApi.Services;
using PruebApi; 

System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);

var builder = WebApplication.CreateBuilder(args);


var configuration = builder.Configuration;

// CONTROLLERS

builder.Services.AddControllers();
builder.Services.AddScoped<IEmployeeImportService, EmployeeImportService>();
builder.Services.AddCors(options =>
{
    options.AddPolicy(name: "CorsPolicy",
        policy =>
        {
            // **IMPORTANTE**: Reemplaza 3000 si tu front-end usa otro puerto.
            policy.WithOrigins("http://localhost:3000") 
                .AllowAnyHeader()
                .AllowAnyMethod()
                .AllowCredentials(); // Necesario si manejas cookies o tokens JWT
        });
});
// AUTOMAPPER
builder.Services.AddAutoMapper(typeof(MappingProfile));

// DB CONTEXT (MySQL)
builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseMySql(configuration.GetConnectionString("DefaultConnection"),
        new MySqlServerVersion(new Version(8, 0, 0)))
);

// REGISTRO DE LA CONFIGURACIÓN SMTP
builder.Services.Configure<SmtpSettings>(
    builder.Configuration.GetSection("Smtp"));
// A. Registramos la implementación concreta para que EmployeeService pueda inyectarla
builder.Services.AddScoped<PruebApi.Services.Implementations.EmailService>();

// B. (Opcional pero recomendado) Registramos la interfaz por si otros servicios la usan
builder.Services.AddScoped<IEmailService, PruebApi.Services.Implementations.EmailService>();

// REGISTRO DEL SERVICIO DE CORREO
builder.Services.AddScoped<IEmailService, EmailService>();


// REPOSITORIES & SERVICES
builder.Services.AddScoped<IEmployeeRepository, EmployeeRepository>();
builder.Services.AddScoped<IEmployeeService, EmployeeService>();
builder.Services.AddScoped<IAuthService, AuthService>();

// JWT SETTINGS
var jwtSection = configuration.GetSection("Jwt");
builder.Services.Configure<JwtSettings>(jwtSection);

var jwtSettings = jwtSection.Get<JwtSettings>()!;
var key = Encoding.UTF8.GetBytes(jwtSettings.Key);

// JWT AUTHENTICATION
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;

    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidIssuer = jwtSettings.Issuer,

        ValidateAudience = true,
        ValidAudience = jwtSettings.Audience,

        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(key),

        ValidateLifetime = true,
        ClockSkew = TimeSpan.Zero
    };
});

// SWAGGER + JWT
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "PruebApi",
        Version = "v1"
    });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Ingrese: Bearer {token}"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});


var app = builder.Build();

// DATABASE AUTOMATIC MIGRATION (OPTIONAL)
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.Migrate();
}

// SEED SOLO EN DEVELOPMENT
if (app.Environment.IsDevelopment())
{
    using var scope = app.Services.CreateScope();
    var ctx = scope.ServiceProvider.GetRequiredService<AppDbContext>();

    if (!ctx.Employees.Any())
    {
        ctx.Employees.AddRange(new[]
        {
            new Employee 
            { 
                Document = "12345678", // Nuevo
                FirstName = "Juan", 
                LastName = "Perez", 
                Email = "juan@ejemplo.com",
                DateOfBirth = new DateTime(1990, 5, 15), // Nuevo
                Address = "Calle Falsa 123", // Soluciona el error 'Address cannot be null'
                Phone = "555-1234", // Nuevo
                Position = "Desarrollador", // Nuevo
                Salary = 60000.00m, // Nuevo (usa 'm' para decimal)
                HireDate = DateTime.Now, // Nuevo
                Status = "Activo", // Nuevo
                EducationLevel = "Universitario", // Nuevo
                ProfessionalProfile = "Full Stack Dev", // Nuevo
                Department = "IT" // Nuevo
            },
            new Employee 
            { 
                Document = "87654321", // Nuevo
                FirstName = "Ana", 
                LastName = "Gomez", 
                Email = "ana@ejemplo.com",
                DateOfBirth = new DateTime(1995, 8, 20), // Nuevo
                Address = "Avenida Siempreviva 742", // Soluciona el error 'Address cannot be null'
                Phone = "555-4321", // Nuevo
                Position = "Diseñador", // Nuevo
                Salary = 45000.00m, // Nuevo
                HireDate = DateTime.Now, // Nuevo
                Status = "Activo", // Nuevo
                EducationLevel = "Técnico", // Nuevo
                ProfessionalProfile = "UX/UI Designer", // Nuevo
                Department = "Diseño" // Nuevo
            }
        });

        ctx.SaveChanges();
    }
    if (!ctx.Users.Any())
    {
        var passwordHash = BCrypt.Net.BCrypt.HashPassword("1234");

        ctx.Users.Add(new User()
        {
            Username = "admin",
            PasswordHash = passwordHash,
            Role = "Admin"
        });

        ctx.SaveChanges();
    }
}

// MIDDLEWARES
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseCors("CorsPolicy");
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
