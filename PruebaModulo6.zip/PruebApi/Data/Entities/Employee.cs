
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PruebApi.Data.Entities;

public class Employee
{
    // Identificador (Clave Primaria)
    public int Id { get; set; }

    // Datos Personales
    public string Document { get; set; } = default!; // Documento
    public string FirstName { get; set; } = default!; // Nombres (Existente)
    public string LastName { get; set; } = default!; // Apellidos (Existente)
    public DateTime DateOfBirth { get; set; } // FechaNacimiento
    public string Address { get; set; } = default!; // Direccion
    public string Phone { get; set; } = default!; // Telefono
    public string Email { get; set; } = default!; // Email (Existente)

    // Datos de Empleo
    public string Position { get; set; } = default!; // Cargo
    
    [Column(TypeName = "decimal(18, 2)")] // Define la precisión decimal para la BD
    public decimal Salary { get; set; } // Salario
    
    public DateTime HireDate { get; set; } // FechaIngreso
    public string Status { get; set; } = default!; // Estado

    // Información Educativa y Profesional
    public string EducationLevel { get; set; } = default!; // NivelEducativo
    public string ProfessionalProfile { get; set; } = default!; // PerfilProfesional
    public string Department { get; set; } = default!; // Departamento

}