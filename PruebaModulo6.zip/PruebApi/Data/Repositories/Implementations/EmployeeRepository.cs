using Microsoft.EntityFrameworkCore;
using PruebApi.Data.Database;
using PruebApi.Data.Entities;
using PruebApi.Data.Repositories.Interfaces;

namespace PruebApi.Data.Repositories.Implementations;

public class EmployeeRepository : IEmployeeRepository
{
    private readonly AppDbContext _ctx;
    public EmployeeRepository(AppDbContext ctx) => _ctx = ctx;

    public async Task<IEnumerable<Employee>> GetAllAsync() =>
        await _ctx.Employees.AsNoTracking().ToListAsync();

    public async Task<Employee?> GetByIdAsync(int id) =>
        await _ctx.Employees.FindAsync(id);

    public async Task<Employee> AddAsync(Employee employee)
    {
        var e = (await _ctx.Employees.AddAsync(employee)).Entity;
        await _ctx.SaveChangesAsync();
        return e;
    }

    public async Task UpdateAsync(Employee employee)
    {
        _ctx.Employees.Update(employee);
        await _ctx.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var e = await _ctx.Employees.FindAsync(id);
        if (e == null) return;
        _ctx.Employees.Remove(e);
        await _ctx.SaveChangesAsync();
    }
}