using AutoMapper;
using PruebApi.Data.Entities;
using PruebApi.Data.Repositories.Interfaces;
using PruebApi.DTOs;
using PruebApi.Services.Interfaces;

namespace PruebApi.Services.Implementations
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _repo;
        private readonly IMapper _mapper;
        private readonly EmailService _emailService;

        public EmployeeService(IEmployeeRepository repo, IMapper mapper, EmailService emailService)
        {
            _repo = repo;
            _mapper = mapper;
            _emailService = emailService; // Inyección correcta
        }

        public async Task<IEnumerable<EmployeeDto>> GetAllAsync()
        {
            var list = await _repo.GetAllAsync();
            return _mapper.Map<IEnumerable<EmployeeDto>>(list);
        }

        public async Task<EmployeeDto?> GetByIdAsync(int id)
        {
            var e = await _repo.GetByIdAsync(id);
            return e == null ? null : _mapper.Map<EmployeeDto>(e);
        }

        public async Task<EmployeeDto> CreateAsync(EmployeeDto dto)
        {
            // Map DTO → Entity
            var entity = _mapper.Map<Employee>(dto);

            // Save to DB
            var created = await _repo.AddAsync(entity);

            // Send welcome email
            try
            {
                await _emailService.SendEmailAsync(
                    created.Email,
                    "Bienvenido a la empresa",
                    $@"
                        <h2>Hola {created.FirstName} {created.LastName}</h2>
                        <p>Tu registro en la empresa se ha creado correctamente.</p>
                        <p><b>Cargo:</b> {created.Position}</p>
                        <p><b>Departamento:</b> {created.Department}</p>

                        <br/>
                        <p>Saludos,</p>
                        <p>Equipo de Recursos Humanos</p>
                    "
                );
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Error enviando correo: " + ex.Message);
            }

            return _mapper.Map<EmployeeDto>(created);
        }

        public async Task UpdateAsync(int id, EmployeeDto dto)
        {
            var existing = await _repo.GetByIdAsync(id);

            if (existing == null)
                throw new KeyNotFoundException("Empleado no encontrado");

            _mapper.Map(dto, existing);

            await _repo.UpdateAsync(existing);
        }

        public async Task DeleteAsync(int id)
        {
            await _repo.DeleteAsync(id);
        }
    }
}
