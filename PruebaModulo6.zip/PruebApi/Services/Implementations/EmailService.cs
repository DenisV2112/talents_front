// PruebApi.Services.Implementations/EmailService.cs

using Microsoft.Extensions.Options;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using PruebApi.Services.Interfaces;
using PruebApi; // Para acceder a SmtpSettings

namespace PruebApi.Services.Implementations
{
    // 🚨 IMPLEMENTAMOS LA INTERFAZ aunque EmployeeService inyecte la clase concreta
    public class EmailService : IEmailService
    {
        private readonly SmtpSettings _smtpSettings;

        // Inyectamos IOptions<SmtpSettings>
        public EmailService(IOptions<SmtpSettings> smtpSettings)
        {
            _smtpSettings = smtpSettings.Value;
        }

        public async Task SendEmailAsync(string toEmail, string subject, string body)
        {
            var mail = new MailMessage
            {
                From = new MailAddress(_smtpSettings.User, _smtpSettings.SenderName),
                Subject = subject,
                Body = body,
                IsBodyHtml = true,
            };
            mail.To.Add(new MailAddress(toEmail));

            using (var smtpClient = new SmtpClient(_smtpSettings.Host, _smtpSettings.Port))
            {
                smtpClient.Credentials = new NetworkCredential(_smtpSettings.User, _smtpSettings.Pass);
                
                // CRÍTICO para GMail
                smtpClient.EnableSsl = true; 
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpClient.UseDefaultCredentials = false; 

                try
                {
                    await smtpClient.SendMailAsync(mail);
                }
                catch (SmtpException ex)
                {
                    Console.WriteLine($"Error SMTP: {ex.Message}");
                    throw new Exception("Fallo en el servicio de correo.", ex);
                }
            }
        }
    }
}