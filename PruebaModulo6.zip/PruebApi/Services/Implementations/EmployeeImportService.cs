// PruebApi.Services.Implementations/EmployeeImportService.cs

using ExcelDataReader;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore; // Requerido para AddRangeAsync y BeginTransactionAsync
using PruebApi.Data.Database; // Requerido para AppDbContext
using PruebApi.Data.Entities; // Requerido para Employee entity
using PruebApi.Services.Interfaces; // Requerido para la interfaz
using System.IO; // Requerido para OpenReadStream
using System.Data; // Requerido para métodos de ExcelDataReader
using System.Collections.Generic; // Requerido para List<Employee>
using System; // Requerido para Exception, DateTime, ArgumentException

namespace PruebApi.Services.Implementations;

public class EmployeeImportService : IEmployeeImportService
{
    private readonly AppDbContext _context;
    
    // El constructor solo inyecta el DbContext, eliminando la dependencia del Repositorio.
    public EmployeeImportService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<int> ImportFromExcelAsync(IFormFile file)
    {
        if (file == null || file.Length == 0)
        {
            throw new ArgumentException("El archivo es inválido o está vacío.");
        }

        var employeesToImport = new List<Employee>();

        try
        {
            using (var stream = file.OpenReadStream())
            {
                IExcelDataReader reader;
                if (file.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
                {
                    reader = ExcelReaderFactory.CreateCsvReader(stream);
                }
                else
                {
                    reader = ExcelReaderFactory.CreateReader(stream);
                }

                using (reader)
                {
                    // Saltar la primera fila (encabezados)
                    if (reader.Read()) 
                    {
                        while (reader.Read())
                        {
                            try
                            {
                                var employee = new Employee
                                {
                                    // Usamos 'as string' para mayor seguridad con valores nulos de GetValue
                                    Document = (reader.GetValue(0) as string) ?? string.Empty,
                                    FirstName = (reader.GetValue(1) as string) ?? string.Empty,
                                    LastName = (reader.GetValue(2) as string) ?? string.Empty,
                                    DateOfBirth = ParseDate(reader.GetValue(3)), 
                                    Address = (reader.GetValue(4) as string) ?? string.Empty,
                                    Phone = (reader.GetValue(5) as string) ?? string.Empty,
                                    Email = (reader.GetValue(6) as string) ?? string.Empty,
                                    Position = (reader.GetValue(7) as string) ?? string.Empty,
                                    Salary = ParseDecimal(reader.GetValue(8)),
                                    HireDate = ParseDate(reader.GetValue(9)), 
                                    Status = (reader.GetValue(10) as string) ?? string.Empty,
                                    EducationLevel = (reader.GetValue(11) as string) ?? string.Empty,
                                    ProfessionalProfile = (reader.GetValue(12) as string) ?? string.Empty,
                                    Department = (reader.GetValue(13) as string) ?? string.Empty,
                                };

                                employeesToImport.Add(employee);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Error al procesar fila: {ex.Message}");
                            }
                        }
                    }
                }
            }

            // 4. Guardar los Datos en la Base de Datos con Transacción
            // Uso de 'await using' para la transacción asíncrona (IAsyncDisposable)
            await using var transaction = await _context.Database.BeginTransactionAsync();
            {
                try
                {
                    // **CORRECCIÓN CLAVE:** Usar _context.Employees para AddRangeAsync
                    await _context.Employees.AddRangeAsync(employeesToImport); 
                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();
                    
                    return employeesToImport.Count;
                }
                catch (Exception ex)
                {
                    await transaction.RollbackAsync();
                    throw new Exception($"Falló la operación de guardado en la base de datos. Detalle: {ex.Message}"); 
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception($"Error en la importación del archivo: {ex.Message}");
        }
    }
    
    // Métodos Auxiliares
    private DateTime ParseDate(object value)
    {
        if (value == null) return default;
        
        // Si el valor ya es DateTime (común en ExcelDataReader)
        if (value is DateTime dateResult)
            return dateResult;
        
        // Intenta parsear desde string
        if (DateTime.TryParse(value.ToString(), out dateResult))
            return dateResult;
        
        // Intenta convertir OADate (número de días en Excel)
        if (double.TryParse(value.ToString(), out var doubleValue))
            return DateTime.FromOADate(doubleValue);

        return default; 
    }

    private decimal ParseDecimal(object value)
    {
        if (value == null) return 0.00m;
        
        var stringValue = value.ToString()
                               .Replace("$", "")
                               .Replace(",", "") // Puede que necesites cambiar esto si el separador decimal es la coma
                               .Trim();
        
        if (decimal.TryParse(stringValue, out var result))
            return result;
        
        return 0.00m;
    }
}