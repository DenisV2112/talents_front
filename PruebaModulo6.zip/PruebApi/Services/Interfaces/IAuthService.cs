namespace PruebApi.Services.Interfaces;

public interface IAuthService
{
    string GenerateToken(string userId, string userName);
}