// PruebApi.Services.Interfaces/IEmployeeImportService.cs

using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace PruebApi.Services.Interfaces;

public interface IEmployeeImportService
{
    /// <summary>
    /// Procesa y guarda los datos de empleados de un archivo Excel o CSV.
    /// </summary>
    /// <param name="file">El archivo subido.</param>
    /// <returns>El número total de empleados importados con éxito.</returns>
    Task<int> ImportFromExcelAsync(IFormFile file);
}