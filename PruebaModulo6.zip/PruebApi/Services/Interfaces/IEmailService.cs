// PruebApi.Services.Interfaces/IEmailService.cs

using System.Threading.Tasks;

namespace PruebApi.Services.Interfaces
{
    public interface IEmailService
    {
        // Tu EmployeeService espera que el método sea SendEmailAsync
        Task SendEmailAsync(string toEmail, string subject, string body);
    }
}