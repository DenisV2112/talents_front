// PruebApi.Controllers/EmployeeImportController.cs

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using PruebApi.Services.Interfaces; // Asegúrate de que este using esté aquí

namespace PruebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class EmployeeImportController : ControllerBase
{
    private readonly IEmployeeImportService _importSvc; // CAMBIADO a la nueva interfaz

    // Cambiado el tipo de inyección
    public EmployeeImportController(IEmployeeImportService importSvc)
    {
        _importSvc = importSvc;
    }

    [HttpPost("upload")]
    [Authorize]
    public async Task<IActionResult> UploadExcel(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("Debe enviar un archivo Excel.");

        try
        {
            // Llama al servicio de importación independiente
            var totalImported = await _importSvc.ImportFromExcelAsync(file);

            return Ok(new {
                message = "Archivo procesado correctamente",
                totalImported = totalImported
            });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Error al importar datos: {ex.Message}");
        }
    }
}