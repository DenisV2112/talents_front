// PruebApi.DTOs/EmployeeDto.cs

using System;

namespace PruebApi.DTOs;

public class EmployeeDto
{
    // Identificador
    public int Id { get; set; }

    // Datos Personales
    public string Document { get; set; } = default!; // Documento
    public string FirstName { get; set; } = default!; // Nombres
    public string LastName { get; set; } = default!; // Apellidos
    public DateTime DateOfBirth { get; set; } // FechaNacimiento
    public string Address { get; set; } = default!; // Direccion
    public string Phone { get; set; } = default!; // Telefono
    public string Email { get; set; } = default!; // Email

    // Datos de Empleo
    public string Position { get; set; } = default!; // Cargo
    public decimal Salary { get; set; } // Salario
    public DateTime HireDate { get; set; } // FechaIngreso
    public string Status { get; set; } = default!; // Estado

    // Información Educativa y Profesional
    public string EducationLevel { get; set; } = default!; // NivelEducativo
    public string ProfessionalProfile { get; set; } = default!; // PerfilProfesional
    public string Department { get; set; } = default!; // Departamento
}